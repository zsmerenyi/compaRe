# open libraries
rm(list=ls())
options(max.print = 99999999)
options(width = 10000)
options(java.parameters = "-Xmx8000m") #https://stackoverflow.com/questions/21937640/handling-java-lang-outofmemoryerror-when-writing-to-excel-from-r
suppressMessages(library(readr))
suppressMessages(library(stringr))
suppressMessages(library(tibble))
suppressMessages(library(tidyr))
suppressMessages(library(dplyr))
suppressMessages(library(ape))
sz<-function(vmi){length(unique(vmi))}
SD<-format(Sys.Date(), format="%y%m%d")

#setwd("D:/0_scriptek/Termdupdet_example/")
args <- commandArgs(TRUE)    
fold = args[1]               # folder name with tre files  fold="example"
mit = args[2]                # 0-erase all duplicated proteins (stricter) 1- retain the best one (min AAdist)   
cpusz = as.numeric(args[3])  # no of cpu cpusz=1

lft<-list.files(fold,pattern = "tre",full.names = T)
lft<-lft[sapply(lft,file.size) > 10]  # only those files which are reliable 
sz(lft)


if(fold=="--h"|fold=="-h"|fold=="-help"){
  cat("example command: Rscript Terminaldupdet230308.R example/ 1 10 \n")
  cat(" argument 1: folder name with tre files \n")
  cat(" argument 2: 0-erase all duplicated proteins (stricter) | 1- retain the best one (min AAdist)\n")
  cat(" argument 3: number of cpu\n\n")
  cat(" version: 20230308\n")
  cat("\n\n\n")
}else{
  


# ------------------------------------------------------------------------------------------
# function to get species name from JGI name format
spresz<-function(s){
  s2<-str_split(s,"_")
  s3<-sapply(1:length(s2), function(x) paste0(s2[[x]][1:(length(s2[[x]])-1)],collapse = "_") )
  return(s3)
}

# function to filter duplications based on their type (monophyletic or not)
# If TRUE (monofiletic) all the duplications are monophyletic (within a species)
# x<-lft[[3]]
treenezo<-function(x){
  jok<-NULL
  at<-read.tree(x)
  names<-at$tip.label
  spk<-spresz(names) 
  db<-table(spk)
  dupsp<-db[db>1]
  if(length(dupsp)>0){
  MF<-sapply(1:length(dupsp),function(v) is.monophyletic(at,which(grepl(names(dupsp[v]),at$tip.label))))
  if(all(MF)){jok<-x}else{jok<-NULL}}else{MF<-TRUE}
  return(MF)
}

# function: species names from tree
fajnevek<-function(x){
  at<-read.tree(x)
  names<-at$tip.label
  spk<-spresz(names) #sapply(str_split(names,"_"), "[", 1)
  return(spk)
}

# factor to chr converter
chrelo<-function(TABLE,x){TABLE[,x]<-as.numeric(as.character(TABLE[,x][[1]]))}

# function which masure the coverage between aligned sequences
covszr<-function(ill){  
  alib<-ill  
  alibs<-as.character(alib)
  alibs0<-str_replace_all(alibs,"-","0")
  alibs1<-str_replace_all(alibs0,"[:alpha:]","1")
  alibst<-str_split(alibs1,"|")
  alib3<-do.call(rbind,alibst)
  adt<-as.data.frame(alib3)
  adt2<-adt[,c(2:(ncol(adt)-1))]
  rownames(adt2)<-names(alib)
  st<-Sys.time() 
  adt3<-as_tibble(adt2)
  adt4<-as_tibble(sapply(1:ncol(adt3), function(v) chrelo(adt3,v)))
  B <- Matrix(as.matrix(adt4), sparse = TRUE)
  allsite<-dist.matrix(B, method = "minkowski", p=0)
  diffsite<-dist.matrix(B, method = "minkowski", p=1) 
  covdist<- (1-((allsite-diffsite)/allsite))
  colnames(covdist)<-names(alib)
  rownames(covdist)<-names(alib)
  cat("\t",Sys.time()-st,"\n") 
  return(covdist)
}

#------------------------------------------------
#################### parallel in a Server
library(parallel)
st<-Sys.time()
SR<-mclapply(lft,FUN=treenezo, mc.cores=cpusz) #<-------------cpcores
Sys.time()-st
names(SR)<-lft

er2<-sapply(SR,function(x) all(x))
er2<-as_tibble(er2)
er2$file<-names(SR)
table(er2$value)
jok<-er2[er2$value==TRUE,]
jok$kell<-jok$file
jok$kell<-str_replace(jok$kell,"FT.tre","M.fas")
#jok$kell<-sapply(str_split(jok$kell,"/"), "[", 2)
writeLines(jok$kell, con = "onlyterminalduplication.tsv")

# collecting species names
fna<-NULL
for (i in jok$file){ #jok$file
  cat(i,'\t')
  er<-fajnevek(i)
  #cat(all(er),'\n')
  fna<-c(fna,er)
}
spnames<-unique(fna)
length(spnames)

lfas<-list.files(path="./xkiv",pattern = "M.fas", full.names = T)
lfas<-jok$kell

# this part can eliminate the duplicated proteins from the MSA
suppressMessages(library("DECIPHER"))
q=1
allprot<-NULL
for(i in lfas){
  #i<-lfas[1]
  cat(i,"\n")
  clnev<-sapply(str_split(i,"M\\."), "[", 1)
  clnev<-rev(str_split(clnev,"\\/")[[1]])[[1]]
  alio<-readAAStringSet(i)
  dmp<-ifelse(round(log10(length(alio)),0)>= 4,2,round(log10(length(alio)),0)) # CPU maxolas!!!!!
  aliDM<-DistanceMatrix(alio,penalizeGapGapMatches=FALSE, processors = dmp) #distmatrix a teljes illesztesre (karakteralapu)
  #covM<-covszr(alio)
  prots<-data.frame(names(alio))
  prots$spec<-spresz(names(alio))
  prots$dup<-0
  fa<-names(table(prots$spec))[table(prots$spec)>1] # duplicated species
  prots[which(prots$spec %in% fa),"dup"]<-1
  kivall<-NULL
  for(g in fa){                    # iterate among the duplicated species
    #g<-fa[1]
    cat(g)
    aamx<-aliDM[which(grepl(g,rownames(aliDM))),-which(grepl(g,rownames(aliDM)))] # one species vs all other protein
    aamx<-as.matrix(aamx)
    cname<-rownames(aamx)
    compet<-sapply(1:nrow(aamx), function(d) min(aamx[d,])) # minimal AAdistance from the duplicates
    marad<-cname[which.min(compet)]
    kivesz<-setdiff(rownames(aamx),marad) # which is not minimal we should erase from the alignment
    kivall<-c(kivall,kivesz)
  }
  prots$elim<-0
  prots[which(prots$names.alio. %in% kivall),"elim"]<-1
  prots$del<-prots$dup+prots$elim
  if(mit==0){
    # we eliminate all the proteins from a species which showed duplication
    del<-prots[which(prots$del>0),]
  }else{
    # we retain that protein which showed the minimal AAdistance from the other proteins  
    del<-prots[which(prots$del>1),]
  }
  aliv<-alio[-which(names(alio) %in% del$names.alio.)] # here we get rid of duplicated proteins
  #prots$del<-0
  prots[which(prots$names.alio. %in% del$names.alio.),"del"]<-"X"
  prots$file<-i
  allprot<-rbind(allprot,prots)
  ########
  if( length(names(aliv))>=3 ){   #<------------- minimal species threshold
    writeXStringSet(aliv,paste0(clnev,"_m",mit,".fas"))
  }else{
    cat(i,"too few proteins left\n")
  }
}

write.table(allprot, file=paste0('Allprottable_m',mit,'.csv'), quote=FALSE, sep=',', col.names = T, row.names = F)
  
# 0 is the non-duplicated prots
# 1 (if present) the retained prots which showed minimal distance with prots in 0
# X the deleted prots: all duplicated or just those which showed non-minimal AAdistance from prots in 0
summary<-as.data.frame.matrix(table(allprot$file,allprot$del))
summary$filename<-rownames(summary)
comment<-ifelse(mit==0,"0-erase all duplication","1-retain 1 prot from all species; having duplication; those ones which has the lowest AAdist from other prots")
summary<-rbind(summary,c("setup:",fold,comment))

write.table(summary, file=paste0('SUMMARY_dupdet_m',mit,'.csv'), quote=FALSE, sep=',', col.names = T, row.names = F)

}

