Terminaldupdet230308.R script can detect and eliminate terminally duplicated sequences from Multiple Sequence Alignment (MSA). It is useful for extending the set of single copy orthologues for species tree reconstruction.


currently for the script it is important to use input files with the following endings: 
..MT.fas are the aligned, trimmed sequence (e.g.: trimal -gt 0.4)
..FT.tre are a tree based on MT.fas (e.g.: FastTree)
Also important to use species name as prefix like: Copci_AmutBmut1_12345 where Copci_AmutBmut1_ is the species name and 12345 is the unique idendifyer of the protein ID.
If this file structure is ready, you just type this command into the prompt:
Rscript Terminaldupdet230308.R example 0 20
where the first argument: example is the folder name where MT.fas and FT.tree files are located
second argument: 
	0 if we want to erase all duplicated proteins (strict) 
	1 if we want to retain the best one from each species has duplicated proteins (the decision based on min AAdist) from the non duplicated proteins
third argument: 20 is the number of CPUs that you want to give this task.

At first, the script analyzes all the FT.tre files (trees) whether the duplications form a monophyletic group in the gene tree (terminal duplication) or not. in this step possibly you will lose most of your gene families.
If all the duplications are terminal in a gene tree, the script will open the MSA (M.fas) and do an amino acid distance and coverage matrix to decide which protein shows the minimal distance from the other members of the gene family for each species (which contains duplication). 
Then based on the second argument (0 or 1 see above) all duplicated proteins or all but one will be eliminated from the MSA file.  
The result file will be written to the root folder with _m0.fas or _m1.fas (depending on argument 2) tag.

output files: 
 - MSA without duplicated proteins with _m0.fas or _m1.fas tag
 - onlyterminalduplication.tsv those MSA which has only terminal duplications (and not deep paralogues)
 - Allprottable_m0.csv or Allprottable_m1.csv a table from all proteins where 
	column dup 0-non duplicated 1-duplicated species 
	column elim 1-those duplicated proteins which showed higher AA distance from the non duplicated sequences
	column del 0-retained proteins 1-retained, duplicated proteins, X- deleted proteins 
